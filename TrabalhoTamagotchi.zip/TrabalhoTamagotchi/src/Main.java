import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Main {

    private String nome;
    private int fome;
    private int felicidade;
    private int higiene;
    private int idade;
    private int energia;
    private int cicloVida;
    private int saude;

    public Main(String nome) {
        this.nome = nome;
        this.fome = 100;
        this.felicidade = 100;
        this.higiene = 100;
        this.idade = 0;
        this.energia = 100;
        this.saude = 100;
        this.cicloVida = 0;
    }

    public String getStatus() {
        return "Nome: " + nome + "\n" +
                "Idade: " + idade + " dias\n" +
                ((fome <= 50) ? "(ALERTA) " + nome + " está com fome!\n" : "") +
                "Fome: " + fome + "%\n" +
                "Felicidade: " + felicidade + "%\n" +
                ((higiene <= 50) ? "(ALERTA) " + nome + " está sujo!\n" : "") +
                "Higiene: " + higiene + "%\n" +
                ((energia <= 50) ? "(ALERTA) " + nome + " está cansado!\n" :
                        (energia >= 90) ? "(ALERTA) " + nome + " quer brincar!\n" : "") +
                "Energia: " + energia + "%\n" +
                "Saúde: " + saude + "%\n" +
                "Estágio de Vida: " + getCicloVida();
    }

    private String getCicloVida() {
        if (idade >= 0 && idade <= 2) {
            return "Criança";
        } else if (idade >= 3 && idade <= 4) {
            return "Adolescente";
        } else if (idade >= 5 && idade <= 7) {
            return "Adulto";
        } else if (idade >= 8 && idade <= 12) {
            return "Velho";
        } else {
            return "Ancestral";
        }
    }

    public void alimentar(int opcao) {
        Random random = new Random();

        switch (opcao) {
            case 1:
                fome += 20;
                saude += 5;
                JOptionPane.showMessageDialog(null, nome + ": * Chomp Chomp Chomp * Que delícia!\n\nAtributos ganhos:\nFome +20\nSaúde +5");
                break;
            case 2:
                fome += 15;
                saude += 5;
                JOptionPane.showMessageDialog(null, nome + ": * Munch Munch Munch * Delicioso!\n\nAtributos ganhos:\nFome +15\nSaúde +5");
                break;
            case 3:
                fome += 10;
                saude += 5;
                JOptionPane.showMessageDialog(null, nome + ": * Crunch Crunch Crunch * Estou gostando disso!\n\nAtributos ganhos:\nFome +10\nSaúde +5");
                break;
            case 4:
                fome += 10;
                saude += 5;
                JOptionPane.showMessageDialog(null, nome + ": * Slurp Slurp Slurp * Que refrescante!\n\nAtributos ganhos:\nFome +10\nSaúde +5");
                break;
            case 5:
                fome += 25;
                saude += 15;
                JOptionPane.showMessageDialog(null, nome + ": * Nom Nom Nom * Uau, que saboroso!\n\nAtributos ganhos:\nFome +25\nSaúde +15");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Opção de alimento inválida!");
                return;
        }

        if (fome > 100) {
            fome = 100;
        }
        if (saude > 100) {
            saude = 100;
        }
        if (felicidade > 100) {
            felicidade = 100;
        }
        if (higiene > 100) {
            higiene = 100;
        }
        if (energia > 100) {
            energia = 100;
        }
    }

    public void brincar(int opcao) {
        Random random = new Random();

        switch (opcao) {
            case 1:
                felicidade += 20;
                if (felicidade > 100) {
                    felicidade = 100;
                }
                higiene -= 20;
                energia -= 20;
                fome -= 15;
                JOptionPane.showMessageDialog(null, nome + ": Que legal! Correr no parque é muito divertido!\n\nAtributos ganhos:\nFelicidade +20\nHigiene -20\nEnergia -20\nFome -15");
                break;
            case 2:
                felicidade += 15;
                if (felicidade > 100) {
                    felicidade = 100;
                }
                higiene -= 15;
                energia -= 15;
                fome -= 15;
                JOptionPane.showMessageDialog(null, nome + ": Vamos jogar bola, isso vai ser demais!\n\nAtributos ganhos:\nFelicidade +15\nHigiene -15\nEnergia -15\nFome -15");
                break;
            case 3:
                felicidade += 10;
                if (felicidade > 100) {
                    felicidade = 100;
                }
                higiene -= 10;
                energia -= 10;
                fome -= 15;
                JOptionPane.showMessageDialog(null, nome + ": Onde será que ele está? Haha, essa brincadeira é ótima!\n\nAtributos ganhos:\nFelicidade +10\nHigiene -10\nEnergia -10\nFome -15");
                break;
            case 4:
                felicidade += 10;
                if (felicidade > 100) {
                    felicidade = 100;
                }
                higiene -= 10;
                energia -= 10;
                fome -= 15;
                JOptionPane.showMessageDialog(null, nome + ": Pular corda é uma diversão saudável!\n\nAtributos ganhos:\nFelicidade +10\nHigiene -10\nEnergia -10\nFome -15");
                break;
            case 5:
                felicidade += 25;
                if (felicidade > 100) {
                    felicidade = 100;
                }
                higiene -= 25;
                energia -= 25;
                fome -= 15;
                JOptionPane.showMessageDialog(null, nome + ": Olha só as bolhas! Isso é muito legal!\n\nAtributos ganhos:\nFelicidade +25\nHigiene -25\nEnergia -25\nFome -15");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Opção de brincadeira inválida!");
                return;
        }
        if (felicidade > 100) {
            felicidade = 100;
        }
    }

        public void limpar() {
        if (higiene < 100) {
            higiene = 100;
            energia -= 5;

            JOptionPane.showMessageDialog(null, nome + ": Adoro tomar banho de espuma! \n\n Higiene restaurada!");
        } else {
            JOptionPane.showMessageDialog(null, nome + ": Já estou limpo. Não é necessário outro banho agora.");
        }
    }

    public void dormir() {
        if (energia < 100) {
            energia = 100;
            JOptionPane.showMessageDialog(null, nome + ": Zzz... Zzz... Zzz... \n\n Energia restaurada");
        } else {
            JOptionPane.showMessageDialog(null, nome + ": Eu já descansei bastante.");
        }
    }

    public void passarTempo() {
        fome -= 10;
        felicidade -= 10;
        higiene -= 10;
        energia += 10;
        idade++;

        if (fome <= 0 || felicidade <= 0 || higiene <= 0) {
            JOptionPane.showMessageDialog(null, "Essa não! " + nome + " morreu! :(");
            System.exit(0);
        }

        eventosAleatorios();
    }

    private void eventosAleatorios() {
        Random random = new Random();
        int evento = random.nextInt(6);

        switch (evento) {
            case 0:
                fome += 10;
                felicidade += 20;
                JOptionPane.showMessageDialog(null, nome + " encontrou um petisco! Sua fome diminui e sua felicidade aumenta!\n\nStatus ganho:\nFome +10\nFelicidade +20");
                break;
            case 1:
                energia -= 15;
                JOptionPane.showMessageDialog(null, nome + " está com sede! Sua energia diminui.\n\nStatus ganho:\nEnergia -15");
                break;
            case 2:
                felicidade -= 15;
                JOptionPane.showMessageDialog(null, nome + " está entediado! Sua felicidade diminui.\n\nStatus ganho:\nFelicidade -15");
                break;
            case 3:
                higiene -= 20;
                JOptionPane.showMessageDialog(null, nome + " se cagou todo! Sua higiene diminuiu.\n\nStatus ganho:\nHigiene -20");
                break;
            case 4:
                felicidade += 25;
                JOptionPane.showMessageDialog(null, nome + " recebeu um elogio inesperado! Sua autoestima aumentou.\n\nStatus ganho:\nFelicidade +25");
                break;
            case 5:
                higiene -= 20;
                felicidade += 20;
                saude -= 5;
                JOptionPane.showMessageDialog(null, nome + " pulou no esgoto atrás de uma nota de 2! Que nojo! Mas encontrou o dinheiro.\n\nStatus ganho:\nHigiene -20\nFelicidade +20\nSaúde -5");
            default:
                break;
        }
        if (fome > 100) {
            fome = 100;
        }
        if (saude > 100) {
            saude = 100;
        }
        if (felicidade > 100) {
            felicidade = 100;
        }
        if (higiene > 100) {
            higiene = 100;
        }
        if (energia > 100) {
            energia = 100;
        }
    }

    public static void main(String[] args) {
        String nome = JOptionPane.showInputDialog("Digite o nome do seu Tamagotchi:");
        Main tamagotchi = new Main(nome);

        JFrame statusFrame = new JFrame("Status do Tamagotchi");
        statusFrame.setSize(300, 200);
        statusFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        statusFrame.setLayout(new GridLayout(1, 1));
        JTextArea statusTextArea = new JTextArea();
        statusFrame.add(statusTextArea);

        ImageIcon tamagotchiIcon = new ImageIcon("C:\\Users\\inovefinanceiro\\Downloads\\tamagotchigif (3).gif");
        JLabel tamagotchiLabel = new JLabel(tamagotchiIcon);
        statusFrame.add(tamagotchiLabel);
        statusFrame.setLayout(new GridLayout());

        statusTextArea.setText(tamagotchi.getStatus());

        statusFrame.setVisible(true);

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                statusTextArea.setText(tamagotchi.getStatus());
            }
        }, 0, 1000);

        JFrame frame = new JFrame("Tamagotchi");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(2, 3, 10, 10));

        JButton alimentarButton = new JButton("Alimentar");
        alimentarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame alimentarFrame = new JFrame("Escolher Alimento");
                alimentarFrame.setSize(300, 200);
                alimentarFrame.setLayout(new GridLayout(3, 2, 10, 10));

                JButton bananaButton = new JButton("Banana");
                bananaButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tamagotchi.alimentar(1);
                        alimentarFrame.dispose(); // Fecha a janela de escolha de alimento
                    }
                });
                alimentarFrame.add(bananaButton);

                JButton macaButton = new JButton("Maçã");
                macaButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tamagotchi.alimentar(2);
                        alimentarFrame.dispose(); // Fecha a janela de escolha de alimento
                    }
                });
                alimentarFrame.add(macaButton);

                JButton cenouraButton = new JButton("Cenoura");
                cenouraButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tamagotchi.alimentar(3);
                        alimentarFrame.dispose(); // Fecha a janela de escolha de alimento
                    }
                });
                alimentarFrame.add(cenouraButton);

                JButton pepinoButton = new JButton("Pepino");
                pepinoButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tamagotchi.alimentar(4);
                        alimentarFrame.dispose(); // Fecha a janela de escolha de alimento
                    }
                });
                alimentarFrame.add(pepinoButton);

                JButton morangoButton = new JButton("Morango");
                morangoButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tamagotchi.alimentar(5);
                        alimentarFrame.dispose(); // Fecha a janela de escolha de alimento
                    }
                });
                alimentarFrame.add(morangoButton);

                alimentarFrame.setVisible(true);
            }
        });
        frame.add(alimentarButton);

        JButton brincarButton = new JButton("Brincar");
        brincarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame brincarFrame = new JFrame("Escolher Brincadeira");
                brincarFrame.setSize(300, 200);
                brincarFrame.setLayout(new GridLayout(3, 2, 10, 10));

                JButton correrButton = new JButton("Correr no Parque");
                correrButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tamagotchi.brincar(1);
                        brincarFrame.dispose(); // Fecha a janela de escolha de brincadeira
                    }
                });
                brincarFrame.add(correrButton);

                JButton bolaButton = new JButton("Jogar Bola");
                bolaButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tamagotchi.brincar(2);
                        brincarFrame.dispose(); // Fecha a janela de escolha de brincadeira
                    }
                });
                brincarFrame.add(bolaButton);

                JButton escondeButton = new JButton("Brincar de Esconde-Esconde");
                escondeButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tamagotchi.brincar(3);
                        brincarFrame.dispose(); // Fecha a janela de escolha de brincadeira
                    }
                });
                brincarFrame.add(escondeButton);

                JButton pularButton = new JButton("Pular Corda");
                pularButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tamagotchi.brincar(4);
                        brincarFrame.dispose(); // Fecha a janela de escolha de brincadeira
                    }
                });
                brincarFrame.add(pularButton);

                JButton bolhasButton = new JButton("Brincar com Bolhas de Sabão");
                bolhasButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tamagotchi.brincar(5);
                        brincarFrame.dispose(); // Fecha a janela de escolha de brincadeira
                    }
                });
                brincarFrame.add(bolhasButton);

                brincarFrame.setVisible(true);
            }
        });

        frame.add(brincarButton);

        JButton limparButton = new JButton("Limpar");
        limparButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tamagotchi.limpar();
            }
        });
        frame.add(limparButton);

        JButton passarTempoButton = new JButton("Passar Tempo");
        passarTempoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tamagotchi.passarTempo();
            }
        });
        frame.add(passarTempoButton);

        JButton dormirButton = new JButton("Dormir");
        dormirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tamagotchi.dormir();
            }
        });
        frame.add(dormirButton);

        JButton sairButton = new JButton("Sair");
        sairButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        frame.add(sairButton);

        frame.setVisible(true);
    }
}